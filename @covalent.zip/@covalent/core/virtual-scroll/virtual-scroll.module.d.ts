export declare class CovalentVirtualScrollModule {
}
