/**
 * Generated bundle index. Do not edit.
 */
export * from './index';
export { IconService as ɵb } from './common/services/icon.service';
export { RouterPathService as ɵa } from './common/services/router-path.service';
