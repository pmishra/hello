export declare class CovalentMediaModule {
}
