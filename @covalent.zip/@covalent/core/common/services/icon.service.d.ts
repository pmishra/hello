export declare class IconService {
    private _icons;
    readonly icons: string[];
    filter(query: string): string[];
}
