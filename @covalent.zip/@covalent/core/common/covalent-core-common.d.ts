/**
 * Generated bundle index. Do not edit.
 */
export * from './index';
export { IconService as ɵb } from './services/icon.service';
export { RouterPathService as ɵa } from './services/router-path.service';
