export interface IAnimationOptions {
    anchor?: string;
    duration?: number;
    delay?: number;
}
