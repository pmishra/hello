import { PipeTransform } from '@angular/core';
export declare class TdTimeDifferencePipe implements PipeTransform {
    transform(start: any, end?: any): string;
}
