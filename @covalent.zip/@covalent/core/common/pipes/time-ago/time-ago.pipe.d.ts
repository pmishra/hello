import { PipeTransform } from '@angular/core';
export declare class TdTimeAgoPipe implements PipeTransform {
    transform(time: any, reference?: any): string;
}
