import { PipeTransform } from '@angular/core';
export declare class TdTruncatePipe implements PipeTransform {
    transform(text: any, length: number): string;
}
