import { PipeTransform } from '@angular/core';
export declare class TdBytesPipe implements PipeTransform {
    transform(bytes: any, precision?: number): string;
}
