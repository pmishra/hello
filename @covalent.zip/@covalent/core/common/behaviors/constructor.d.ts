export declare type Constructor<T> = new (...args: any[]) => T;
