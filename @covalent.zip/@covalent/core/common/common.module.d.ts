export declare class CovalentCommonModule {
}
