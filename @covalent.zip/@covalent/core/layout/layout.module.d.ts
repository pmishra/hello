export declare class CovalentLayoutModule {
}
