export declare class CovalentNotificationsModule {
}
