import { Renderer2, ElementRef } from '@angular/core';
export declare class TdExpansionPanelGroupComponent {
    private _renderer;
    private _elementRef;
    constructor(_renderer: Renderer2, _elementRef: ElementRef);
}
