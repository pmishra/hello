export declare class CovalentExpansionPanelModule {
}
