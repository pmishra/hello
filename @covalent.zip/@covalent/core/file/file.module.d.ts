export declare class CovalentFileModule {
}
