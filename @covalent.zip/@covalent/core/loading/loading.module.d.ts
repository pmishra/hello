export declare class CovalentLoadingModule {
}
