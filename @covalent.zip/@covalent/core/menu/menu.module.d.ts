export declare class CovalentMenuModule {
}
