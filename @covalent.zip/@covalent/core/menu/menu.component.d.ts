export declare class TdMenuComponent {
}
