export * from './chips.module';
export * from './chips.component';
