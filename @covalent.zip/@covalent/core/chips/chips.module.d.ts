export declare class CovalentChipsModule {
}
