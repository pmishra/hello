export declare class CovalentDialogsModule {
}
