export declare class CovalentDataTableModule {
}
