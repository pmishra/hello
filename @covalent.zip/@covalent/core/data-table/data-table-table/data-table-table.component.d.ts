import { Renderer2, ElementRef } from '@angular/core';
export declare class TdDataTableTableComponent {
    private _elementRef;
    private _renderer;
    constructor(_elementRef: ElementRef, _renderer: Renderer2);
}
