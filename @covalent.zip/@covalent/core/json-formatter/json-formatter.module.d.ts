export declare class CovalentJsonFormatterModule {
}
