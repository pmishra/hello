export declare class CovalentStepsModule {
}
