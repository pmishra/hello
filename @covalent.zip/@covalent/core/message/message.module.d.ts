export declare class CovalentMessageModule {
}
