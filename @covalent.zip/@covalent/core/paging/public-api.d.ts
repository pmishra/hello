export * from './paging.module';
export * from './paging-bar.component';
