export declare class CovalentPagingModule {
}
