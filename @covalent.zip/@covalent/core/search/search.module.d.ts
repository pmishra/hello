export declare class CovalentSearchModule {
}
